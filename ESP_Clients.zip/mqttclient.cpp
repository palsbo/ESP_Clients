#include <PubSubClient.h>

#include "mqttclient.h"

PubSubClient client;

void mqttcallback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]);
  }
  Serial.println();
}
void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    // Attempt to connect
    if (client.connect("arduinoClient")) {
      Serial.println("connected");
      // Once connected, publish an announcement...
      client.publish("outTopic","hello world");
      // ... and resubscribe
      client.subscribe("inTopic");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 5 seconds before retrying
      delay(5000);
    }
  }
}
MQTTCLIENT::MQTTCLIENT() {
};

void MQTTCLIENT::connect(char * host, int port, char * client, char * user, char * pass) {
};

void MQTTCLIENT::publish(char * topic, char * data) {
};

void MQTTCLIENT::loop() {
};

void MQTTCLIENT::on(char * topic, mqttcb func) {
};

void MQTTCLIENT::subscribe(char * topic) {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
};

