#ifndef MQTTWSCLIENT_H
#define MQTTWSCLIENT_H

typedef void (*mqttwscb)(char * topic, char * data);

class MQTTWSCLIENT {
  private:
  public:
    MQTTWSCLIENT();
    void connect(char * host, int port, char * client, char * user, char * pass);
    void publish(char * topic, char * data);
    void on(char * topic, mqttwscb func);
    void subscribe(char * topic);
    void loop();
};



#endif

