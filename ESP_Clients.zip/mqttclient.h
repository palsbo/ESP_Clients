#ifndef MQTTCLIENT_H
#define MQTTCLIENT_H

typedef void (*mqttcb)(char * topic, char * data);

class MQTTCLIENT {
  private:
  public:
  MQTTCLIENT();
    void connect(char * host, int port, char * client, char * user, char * pass);
    void publish(char * topic, char * data);
    void on(char * topic, mqttcb func);
    void subscribe(char * topic);
    void loop();
};


#endif

