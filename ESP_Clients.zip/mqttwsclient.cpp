
#include "mqttwsclient.h"

MQTTWSCLIENT::MQTTWSCLIENT() {
}

void MQTTWSCLIENT::connect(char * host, int port, char * client, char * user, char * pass) {
};

void MQTTWSCLIENT::loop() {
};

void MQTTWSCLIENT::publish(char * topic, char * data) {
};

void MQTTWSCLIENT::on(char * topic, mqttwscb func) {
};

void MQTTWSCLIENT::subscribe(char * topic) {
};

