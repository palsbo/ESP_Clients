#ifndef MYAPP_H
#define MYAPP_H

#include "webserver.h"
#include "socclient.h"
#include "mqttclient.h"
#include "mqttwsclient.h"

WEBSERVER webserver(80);

class MYAPP {
  private:
  public:
    void begin() {
      webserver.begin();
    }
    void loop() {
      webserver.loop();
    }
} myApp;

#endif
