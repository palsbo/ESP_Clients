#ifndef WSCLIENT_H
#define WSCLIENT_H

typedef void (*wscb)(char * data);

class WSCLIENT {
  private:
  public:
    WSCLIENT();
    void connect(char * host, int port);
    void send(char * key, char * data); //  to do
    void on(char * topic, wscb func);
    void loop();
};


#endif

